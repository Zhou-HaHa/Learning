<template>
  <div class="everrun-report">
    <div class="global-operator">
      <div class="operator-area">
        <label> Time Span: </label>
        <span class="operator-btn" v-for="item in timeSpan">
          <input type="radio" name="realTime" /> {{ item }}
        </span>
      </div>
      <div class="operator-area">
        <label> Physical Machine: </label>
        <input type="checkbox" checked="checked"/> node0
        <input type="checkbox" checked="checked"/> node1
      </div>
      <div class="operator-area">
        <label> Virtual Machine: </label>
        <input type="checkbox" checked="checked"/> MyVM
      </div>
    </div>
    <div class="chart cpu-usage">
      <div class="header">
        <span> Perecentage of Total Capacity (%) </span>
      </div>
    </div>
    <div class="chart disk-read-write">
      <div class="header">
        <span> Disk Bandwith (Bytes/s) </span>
        <div class="operator">
          <input type="checkbox" checked="checked" /> Disk Write
          <input type="checkbox" checked="checked" /> Disk Read
        </div>
      </div>
    </div>
    <div class="chart network-input-output">
      <div class="header">
        <span> Network Bandwith (Bytes/s) </span>
        <div class="operator">
          <input type="checkbox" checked="checked" /> Network Write
          <input type="checkbox" checked="checked" /> Network Read
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.global-operator {
  margin: 20px 0;
}

.global-operator .operator-area  {
  display: inline-block;
}

.global-operator .operator-area label {
  display: block;
  margin-bottom: 10px;
}

.global-operator .operator-btn {
  padding: 5px;
  margin: 5px 10px;
  border: #1f77b4 solid 1px;
  border-radius: 2px;
  cursor: pointer;
}

.global-operator .operator-btn input {
  display: none;
}

.chart {
  position: relative;
}

.chart .header {
  position: absolute;
}

.header .operator {
  display: inline-block;
}
</style>

<script>
import d3 from 'd3';
import EverrunData from 'shared/mock-data.json';
import Chart from 'core/chart.js';
import Series from 'core/series.js';
import { randomInt } from 'helpers/math.js';

function temperatureScale(chart) {
  let axis = this;
  return d3.scale.linear()
    .range([chart.height, 0])
    .domain([
      d3.min(chart.series, function(s) { return d3.min(s.data, axis.accessor); }),
      d3.max(chart.series, function(s) { return d3.max(s.data, axis.accessor); })
    ]);
}

function realtimeScale(chart) {
  let axis = this;
  return d3.time.scale()
    .range([0, chart.width])
    .domain([
      d3.min(chart.series, function(s) { return axis.accessor(s.data[0]); }),
      d3.max(chart.series, function(s) { return axis.accessor(s.data[s.data.length - 1]); })
    ]);
}

function nextDate(date) {
  return new Date((+date) + 10*60*1000);
}

export default {
  data() {
    return {
      timeSpan: ['Live', 'Last 4 Hours', 'Last 24 Hours', 'last Week', 'Last Month', 'Last Year']
    }
  },
  ready() {
    let cpuSeries = [], diskSeries = [], networkSeries = [];
    let vmMap = d3.map(EverrunData, function(d) {
      return d.name;
    });

    vmMap.forEach(function(key, value) {
      cpuSeries.push(new Series(value.cpu[0].name, value.cpu[0].points));
      diskSeries.push(new Series(value.disk[0].name, value.disk[0].points));
      diskSeries.push(new Series(value.disk[1].name, value.disk[1].points));
      networkSeries.push(new Series(value.network[0].name, value.network[0].points));
      networkSeries.push(new Series(value.network[1].name, value.network[1].points));
    });

    function cpuRealtimeData() {
      let lastDate = cpuSeries[0].data[cpuSeries[0].data.length - 1].date,
        plusDate = nextDate(lastDate);
      for (let rt of cpuSeries) {
        rt.data.push({
          date: plusDate,
          value: randomInt(1, 40)
        });
      }
      cpu.datachange();
      for (let rt of cpuSeries) {
        rt.data.shift();
      }
      window.setTimeout(cpuRealtimeData, 3000);
    }

    function diskRealtimeData() {
      let lastDate = diskSeries[0].data[diskSeries[0].data.length - 1].date,
        plusDate = nextDate(lastDate);
      for (let rt of diskSeries) {
        rt.data.push({
          date: plusDate,
          value: randomInt(1, 40)
        });
      }
      disk.datachange();
      for (let rt of diskSeries) {
        rt.data.shift();
      }
      window.setTimeout(diskRealtimeData, 3000);
    }

    function networkRealtimeData() {
      let lastDate = networkSeries[0].data[networkSeries[0].data.length - 1].date,
        plusDate = nextDate(lastDate);
      for (let rt of networkSeries) {
        rt.data.push({
          date: plusDate,
          value: randomInt(1, 40)
        });
      }
      network.datachange();
      for (let rt of networkSeries) {
        rt.data.shift();
      }
      window.setTimeout(networkRealtimeData, 3000);
    }

    let dispatch = Chart.dispatch();
    let cpu = new Chart('.cpu-usage', cpuSeries, {
      height: 200,
      margin: {
        top: 20,
        left: 40,
        bottom: 30
      },
      zoomer: false,
      axes: {
        x: {
          accessor(datum) {
            return datum.date;
          },
          scale: realtimeScale,
          orient: 'bottom',
          ticks: function ticks(chart) {
            return Math.max(chart.width/75, 2);
          }
        },
        y: {
          accessor(datum) {
            return datum.value;
          },
          scale: temperatureScale,
          orient: 'left',
          tickSize: function tickSize(chart) {
            return -chart.width;
          }
        }
      },
      ruler: {
        orient: 'vertical',
        mode: 'hover'
      }
    }).draw('.everrun-report', dispatch);

    let disk = new Chart('.disk-read-write', diskSeries, {
      height: 200,
      margin: {
        top: 20,
        left: 40,
        bottom: 30
      },
      zoomer: false,
      axes: {
        x: {
          accessor(datum) {
            return datum.date;
          },
          scale: realtimeScale,
          orient: 'bottom',
          ticks: function ticks(chart) {
            return Math.max(chart.width/75, 2);
          }
        },
        y: {
          accessor(datum) {
            return datum.value;
          },
          scale: temperatureScale,
          orient: 'left',
          tickSize: function tickSize(chart) {
            return -chart.width;
          }
        }
      },
      ruler: {
        orient: 'vertical',
        mode: 'hover'
      }
    }).draw('.everrun-report', dispatch);

    let network = new Chart('.network-input-output', networkSeries, {
      height: 200,
      margin: {
        top: 20,
        left: 40,
        bottom: 30
      },
      zoomer: false,
      axes: {
        x: {
          accessor(datum) {
            return datum.date;
          },
          scale: realtimeScale,
          orient: 'bottom',
          ticks: function ticks(chart) {
            return Math.max(chart.width/75, 2);
          }
        },
        y: {
          accessor(datum) {
            return datum.value;
          },
          scale: temperatureScale,
          orient: 'left',
          tickSize: function tickSize(chart) {
            return -chart.width;
          }
        }
      },
      ruler: {
        orient: 'vertical',
        mode: 'hover'
      }
    }).draw('.everrun-report', dispatch);

    cpuRealtimeData();
    diskRealtimeData();
    networkRealtimeData();
  }
}
</script>
