import Vue from 'vue'
import EverrunChart from './EverrunChart.vue'


new Vue({
  el: 'body',
  components: { EverrunChart }
})
